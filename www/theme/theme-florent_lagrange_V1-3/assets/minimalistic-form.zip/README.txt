A Pen created at CodePen.io. You can find this one at https://codepen.io/matmarsiglio/pen/HLIor.

 Simple and beautiful contact form. Useful and easy to modify.