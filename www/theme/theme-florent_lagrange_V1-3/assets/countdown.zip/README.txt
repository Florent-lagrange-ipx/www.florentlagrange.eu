A Pen created at CodePen.io. You can find this one at https://codepen.io/Florent_Lagrange/pen/QaGNJv.

 A javascript countdown timer with simple styles