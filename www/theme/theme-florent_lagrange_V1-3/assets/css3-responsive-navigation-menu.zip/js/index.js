(function() {
  // Pure Css responsive menu with dropdowns and
// transition effects


}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiPGFub255bW91cz4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFBQTs7O0FBQUEiLCJzb3VyY2VzQ29udGVudCI6WyIjIFB1cmUgQ3NzIHJlc3BvbnNpdmUgbWVudSB3aXRoIGRyb3Bkb3ducyBhbmRcbiMgdHJhbnNpdGlvbiBlZmZlY3RzIl19
//# sourceURL=coffeescript