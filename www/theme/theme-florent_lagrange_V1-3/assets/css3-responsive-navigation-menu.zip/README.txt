A Pen created at CodePen.io. You can find this one at https://codepen.io/elemental-shift/pen/fxIEa.

 Pure css 3 responsive menu with dropdowns. The blocks are meant to resemble elements on the periodic table